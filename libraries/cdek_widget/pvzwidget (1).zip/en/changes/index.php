<?php
header('Content-Type: text/plain');
echo file_get_contents('../CHANGELOG_EN.md');
